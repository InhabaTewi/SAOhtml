1.click left or right side of clock to change opacity.
2.double click the text to change theme.
3.one click the text see date and weekday